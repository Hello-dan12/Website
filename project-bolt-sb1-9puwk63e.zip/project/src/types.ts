export interface Attraction {
  id: string;
  name: string;
  description: string;
  rating: number;
  image: string;
}

export interface Cuisine {
  id: string;
  name: string;
  description: string;
}

export interface Event {
  id: string;
  name: string;
  date: string;
  description: string;
}

export interface Region {
  id: string;
  name: string;
  description: string;
  image: string;
  mapImage: string;
  rating: number;
  safetyScore: number;
  categories: string[];
  attractions: Attraction[];
  cuisine: Cuisine[];
  events: Event[];
  culture: string;
  bestTimeToVisit: string;
  tips: string[];
}