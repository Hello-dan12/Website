export const regions = [
  {
    id: '1',
    name: 'Tuscany',
    description: 'Tuscany, the cultural heart of Italy, enchants visitors with its rolling hills dotted with cypress trees, medieval hilltop towns, and world-renowned Renaissance art. This region seamlessly blends natural beauty with human artistry, from the sun-drenched vineyards of Chianti to the architectural marvels of Florence. Home to some of history\'s greatest artists and thinkers, Tuscany continues to inspire with its timeless landscapes, rich culinary traditions, and extraordinary cultural heritage.',
    image: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=1200&h=800',
    mapImage: 'https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?auto=format&fit=crop&w=1200&h=800',
    rating: 4.8,
    safetyScore: 9,
    categories: ['historical', 'culinary', 'outdoor'],
    attractions: [
      {
        id: 't1',
        name: 'Florence Cathedral',
        description: 'Iconic cathedral with a terracotta-tiled dome engineered by Brunelleschi and a bell tower by Giotto. Climb to the top for panoramic views of Florence.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1542743408-1fcb82972bd7?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 't2',
        name: 'Uffizi Gallery',
        description: 'One of the most important Italian museums, housing masterpieces by Botticelli, Leonardo da Vinci, and Michelangelo in a historic 16th-century palace.',
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1534260754426-01a1197c9df8?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 't3',
        name: 'Siena',
        description: 'Medieval city famous for its biannual horse race, Il Palio, and the stunning fan-shaped Piazza del Campo.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1534260754426-01a1197c9df8?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 't4',
        name: 'Val d\'Orcia',
        description: 'UNESCO World Heritage site known for its picturesque landscapes, thermal springs, and charming villages.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1534260754426-01a1197c9df8?auto=format&fit=crop&w=1200&h=800'
      }
    ],
    cuisine: [
      {
        id: 'c1',
        name: 'Bistecca alla Fiorentina',
        description: 'Traditional Florentine T-bone steak, grilled to perfection over oak or olive wood.'
      },
      {
        id: 'c2',
        name: 'Ribollita',
        description: 'Hearty vegetable and bread soup, a Tuscan classic representing the region\'s peasant cooking traditions.'
      },
      {
        id: 'c3',
        name: 'Panzanella',
        description: 'Fresh summer salad made with bread, tomatoes, onions, and basil, dressed with olive oil and vinegar.'
      }
    ],
    events: [
      {
        id: 'e1',
        name: 'Palio di Siena',
        date: 'July 2 and August 16',
        description: 'Historic horse race held twice each summer in Siena\'s Piazza del Campo, featuring riders representing different city districts.'
      },
      {
        id: 'e2',
        name: 'Maggio Musicale Fiorentino',
        date: 'April to June',
        description: 'One of Europe\'s oldest and most prestigious classical music festivals.'
      }
    ],
    culture: 'Tuscany is considered the birthplace of the Renaissance and has produced many influential figures in history including Leonardo da Vinci, Michelangelo, and Dante Alighieri. The region\'s cultural landscape is enriched by its traditions in wine-making, artisanal crafts, and the preservation of medieval customs.',
    bestTimeToVisit: 'April to October offers the best weather, though July and August can be very hot and crowded. Spring and fall provide perfect conditions for outdoor activities and wine tasting.',
    tips: [
      'Book major museums in advance to avoid long queues',
      'Many shops close during the afternoon riposo (rest)',
      'Learn a few basic Italian phrases',
      'Try the local wines, especially Chianti and Brunello',
      'Consider renting a car to explore the countryside',
      'Visit smaller towns during peak tourist season',
      'Take a cooking class to learn authentic Tuscan cuisine'
    ]
  },
  {
    id: '2',
    name: 'Venice',
    description: 'Venice, the floating city of dreams, is a masterpiece of architecture and engineering built entirely on water. This enchanting city consists of 118 islands connected by hundreds of bridges, where gondolas glide through narrow canals, and centuries-old palazzos reflect in the shimmering waters. Beyond its famous carnival and romantic allure, Venice is a living museum of Byzantine, Gothic, and Renaissance art, where every corner reveals a new architectural wonder or artistic treasure.',
    image: 'https://images.unsplash.com/photo-1514890547357-a9ee288728e0?auto=format&fit=crop&w=1200&h=800',
    mapImage: 'https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?auto=format&fit=crop&w=1200&h=800',
    rating: 4.7,
    safetyScore: 8,
    categories: ['historical', 'culinary', 'activities'],
    attractions: [
      {
        id: 'v1',
        name: 'St. Mark\'s Basilica',
        description: 'Byzantine marvel with golden mosaics and ornate domes, showcasing Venice\'s historical connection to the East.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1565769583756-b4bd5ba5ce6a?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'v2',
        name: 'Doge\'s Palace',
        description: 'Gothic masterpiece and former residence of Venice\'s rulers, featuring opulent state rooms and the famous Bridge of Sighs.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1565769583756-b4bd5ba5ce6a?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'v3',
        name: 'Rialto Bridge',
        description: 'Iconic 16th-century bridge spanning the Grand Canal, lined with shops and offering spectacular views.',
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1565769583756-b4bd5ba5ce6a?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'v4',
        name: 'Murano and Burano Islands',
        description: 'Famous for glass-making and lace-making respectively, these colorful islands preserve traditional Venetian crafts.',
        rating: 4.6,
        image: 'https://images.unsplash.com/photo-1565769583756-b4bd5ba5ce6a?auto=format&fit=crop&w=1200&h=800'
      }
    ],
    cuisine: [
      {
        id: 'vc1',
        name: 'Risotto al Nero di Seppia',
        description: 'Black squid ink risotto, a striking Venetian specialty that captures the essence of the lagoon.'
      },
      {
        id: 'vc2',
        name: 'Baccalà Mantecato',
        description: 'Creamed cod served on polenta, a traditional Venetian antipasto.'
      },
      {
        id: 'vc3',
        name: 'Cicchetti',
        description: 'Small snacks or side dishes, similar to Spanish tapas, served in traditional bacari (wine bars).'
      }
    ],
    events: [
      {
        id: 've1',
        name: 'Venice Carnival',
        date: 'February',
        description: 'Historic carnival known for elaborate masks, costumes, and grand balls in historic palazzos.'
      },
      {
        id: 've2',
        name: 'Biennale di Venezia',
        date: 'May to November',
        description: 'Prestigious international art and architecture exhibition held in alternate years.'
      },
      {
        id: 've3',
        name: 'Festa del Redentore',
        date: 'Third Sunday of July',
        description: 'Traditional festival featuring a temporary bridge across the Giudecca Canal and spectacular fireworks.'
      }
    ],
    culture: 'Venice has a rich history as a major maritime power and center of trade between Europe and the Orient. The city\'s unique culture is shaped by its isolation in the lagoon, its artistic heritage, and centuries of maritime tradition.',
    bestTimeToVisit: 'September to November offers pleasant weather and fewer crowds. Winter can be atmospheric but cold, while summer is busy and can be uncomfortably humid.',
    tips: [
      'Purchase a vaporetto pass for water transport',
      'Visit early morning or evening to avoid crowds',
      'Be prepared for acqua alta (high water) in winter',
      'Explore the less touristy sestieri (districts)',
      'Book accommodations on the main islands',
      'Try local wines from the Veneto region',
      'Take a guided tour of secret passages in the Doge\'s Palace'
    ]
  },
  {
    id: '3',
    name: 'Rome',
    description: 'Rome, the Eternal City, is a living testament to over three millennia of history, art, and culture. This extraordinary capital seamlessly blends ancient ruins with Renaissance palazzos, Baroque fountains, and modern life. Every street, piazza, and corner tells a story, from the mighty Colosseum to hidden churches housing masterpieces. As the heart of the Roman Empire and the center of the Catholic Church, Rome continues to influence world culture, architecture, and art, while maintaining its characteristic dolce vita lifestyle.',
    image: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=1200&h=800',
    mapImage: 'https://images.unsplash.com/photo-1563911302283-d2bc129e7570?auto=format&fit=crop&w=1200&h=800',
    rating: 4.9,
    safetyScore: 7,
    categories: ['historical', 'culinary', 'activities'],
    attractions: [
      {
        id: 'r1',
        name: 'Colosseum',
        description: 'Ancient amphitheater and iconic symbol of Rome, once hosting gladiatorial contests and public spectacles. The largest amphitheater ever built.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1552432552-06c0b0a94dda?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'r2',
        name: 'Vatican Museums',
        description: 'Vast museum complex featuring art collected by the Catholic Church, including the Sistine Chapel with Michelangelo\'s famous frescoes.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1560184611-ff3e53f00e8f?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'r3',
        name: 'Roman Forum',
        description: 'Ancient city center with temples, government buildings, and public spaces that were the heart of ancient Rome.',
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1552432552-06c0b0a94dda?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'r4',
        name: 'Pantheon',
        description: 'Former Roman temple with the world\'s largest unreinforced concrete dome, now a church and architectural marvel.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1552432552-06c0b0a94dda?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'r5',
        name: 'Trevi Fountain',
        description: 'Baroque fountain famous for the tradition of throwing coins to ensure a return to Rome.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1552432552-06c0b0a94dda?auto=format&fit=crop&w=1200&h=800'
      }
    ],
    cuisine: [
      {
        id: 'rc1',
        name: 'Pasta alla Carbonara',
        description: 'Classic Roman pasta dish with eggs, pecorino cheese, guanciale, and black pepper, representing the city\'s simple yet flavorful cuisine.'
      },
      {
        id: 'rc2',
        name: 'Supplì',
        description: 'Roman rice balls filled with mozzarella and meat ragù, then fried - a popular street food.'
      },
      {
        id: 'rc3',
        name: 'Cacio e Pepe',
        description: 'Traditional pasta dish made with Pecorino Romano cheese and black pepper, exemplifying Roman culinary minimalism.'
      },
      {
        id: 'rc4',
        name: 'Roman-Style Pizza',
        description: 'Thin, crispy pizza served in rectangular slices, different from Neapolitan style.'
      }
    ],
    events: [
      {
        id: 're1',
        name: 'Roma Estate',
        date: 'June to September',
        description: 'Summer festival featuring outdoor concerts, cinema, and cultural events throughout the city.'
      },
      {
        id: 're2',
        name: 'Festa dei Noantri',
        date: 'July',
        description: 'Traditional festival in Trastevere celebrating Roman culture and cuisine.'
      },
      {
        id: 're3',
        name: 'White Night (Notte Bianca)',
        date: 'September',
        description: 'All-night cultural festival with museums and galleries open until dawn.'
      }
    ],
    culture: 'Rome is the heart of ancient Roman civilization and the center of the Catholic Church, with a rich history spanning over two and a half millennia. The city\'s culture is deeply rooted in art, architecture, religion, and a relaxed lifestyle that embraces long lunches and evening passeggiata.',
    bestTimeToVisit: 'March to May or September to November for mild weather and fewer tourists. Spring brings beautiful blooming flowers, while fall offers pleasant temperatures and harvest festivals.',
    tips: [
      'Book skip-the-line tickets for major attractions',
      'Carry water and refill at public fountains',
      'Dress appropriately when visiting churches',
      'Try authentic Roman cuisine in Trastevere',
      'Visit popular sites early morning or late afternoon',
      'Take advantage of free museum days',
      'Learn basic Italian greetings and phrases',
      'Explore lesser-known neighborhoods like Monti and Testaccio',
      'Use public transportation to avoid traffic'
    ]
  },
  {
    id: '4',
    name: 'Amalfi Coast',
    description: 'The Amalfi Coast is a 50-kilometer stretch of coastline along the southern edge of Italy\'s Sorrentine Peninsula, widely considered one of the most scenic and dramatic coastlines in the world. This UNESCO World Heritage site features vertiginous cliffs dotted with colorful villages that seem to defy gravity, cascading down to the turquoise Mediterranean Sea. Each town along the coast has its own character, from glamorous Positano to historic Amalfi, offering a perfect blend of natural beauty, history, and luxurious Mediterranean lifestyle.',
    image: 'https://images.unsplash.com/photo-1633321088355-d0f81134ca3b?auto=format&fit=crop&w=1200&h=800',
    mapImage: 'https://images.unsplash.com/photo-1612698093158-e07ac200d44e?auto=format&fit=crop&w=1200&h=800',
    rating: 4.8,
    safetyScore: 9,
    categories: ['outdoor', 'culinary', 'activities'],
    attractions: [
      {
        id: 'a1',
        name: 'Positano',
        description: 'Cliffside village known for its pebble beachfront, steep, narrow streets lined with boutiques, and iconic colorful houses cascading down to the sea.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1555921015-5532091f6026?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'a2',
        name: 'Path of the Gods',
        description: 'Ancient hiking trail offering breathtaking views of the coastline and connecting mountain villages.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1555921015-5532091f6026?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'a3',
        name: 'Villa Rufolo',
        description: 'Historic villa in Ravello with stunning gardens and panoramic views, hosting summer concerts.',
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1555921015-5532091f6026?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'a4',
        name: 'Emerald Grotto',
        description: 'Natural sea cave known for its brilliant emerald-colored water and underwater nativity scene.',
        rating: 4.6,
        image: 'https://images.unsplash.com/photo-1555921015-5532091f6026?auto=format&fit=crop&w=1200&h=800'
      }
    ],
    cuisine: [
      {
        id: 'ac1',
        name: 'Scialatielli ai Frutti di Mare',
        description: 'Fresh, handmade pasta served with local seafood, a specialty of the Amalfi Coast.'
      },
      {
        id: 'ac2',
        name: 'Delizia al Limone',
        description: 'Lemon-flavored dessert made with local Sfusato Amalfitano lemons.'
      },
      {
        id: 'ac3',
        name: 'Sardenella',
        description: 'Traditional anchovy dish prepared with local herbs and olive oil.'
      }
    ],
    events: [
      {
        id: 'ae1',
        name: 'Ravello Festival',
        date: 'July to September',
        description: 'Classical music festival in the gardens of Villa Rufolo with concerts overlooking the coast.'
      },
      {
        id: 'ae2',
        name: 'Regata delle Antiche Repubbliche Marinare',
        date: 'June',
        description: 'Historic boat race between Italy\'s ancient maritime republics.'
      }
    ],
    culture: 'The Amalfi Coast has been a popular tourist destination since Roman times, known for its maritime history and limoncello production. The region\'s culture is deeply connected to the sea, with fishing traditions, boat building, and paper making being important historical industries.',
    bestTimeToVisit: 'May to October for beach weather, though September is ideal for fewer crowds and perfect swimming conditions. Spring and fall offer mild weather perfect for hiking and sightseeing.',
    tips: [
      'Take the scenic SITA bus between towns',
      'Book accommodations well in advance',
      'Visit the famous limoncello factories',
      'Try the local seafood specialties',
      'Use boats to travel between coastal towns',
      'Visit popular beaches early morning',
      'Book private boat tours for the best views',
      'Wear comfortable shoes for the steep streets',
      'Make dinner reservations in advance'
    ]
  },
  {
    id: '5',
    name: 'Sicily',
    description: 'Sicily, the Mediterranean\'s largest island, is a cultural melting pot shaped by 3,000 years of history. This fascinating island combines Greek temples, Norman churches, and Baroque palazzos with active volcanoes, pristine beaches, and rugged mountains. Its diverse landscape offers everything from snow-capped Mount Etna to golden beaches, while its unique cuisine reflects the island\'s complex history of conquests and cultural exchanges. Each city and town tells its own story, from the ancient streets of Palermo to the elegant baroque architecture of Noto.',
    image: 'https://images.unsplash.com/photo-1583225214464-9296029427aa?auto=format&fit=crop&w=1200&h=800',
    mapImage: 'https://images.unsplash.com/photo-1586016413664-864c0dd8dcb7?auto=format&fit=crop&w=1200&h=800',
    rating: 4.7,
    safetyScore: 7,
    categories: ['historical', 'culinary', 'outdoor'],
    attractions: [
      {
        id: 's1',
        name: 'Mount Etna',
        description: 'Europe\'s largest active volcano offering hiking, wine tasting experiences, and winter skiing opportunities.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1602096683071-3b6dee6b836b?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 's2',
        name: 'Valley of the Temples',
        description: 'Archaeological site in Agrigento featuring well-preserved Greek temples and ancient ruins.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1602096683071-3b6dee6b836b?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 's3',
        name: 'Taormina',
        description: 'Picturesque town perched on a cliff, famous for its ancient Greek theater and stunning views.',
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1602096683071-3b6dee6b836b?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 's4',
        name: 'Aeolian Islands',
        description: 'Volcanic archipelago offering hiking, thermal springs, and black sand beaches.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1602096683071-3b6dee6b836b?auto=format&fit=crop&w=1200&h=800'
      }
    ],
    cuisine: [
      {
        id: 'sc1',
        name: 'Arancini',
        description: 'Stuffed rice balls coated with breadcrumbs and fried, available with various fillings.'
      },
      {
        id: 'sc2',
        name: 'Pasta alla Norma',
        description: 'Pasta with eggplant, tomatoes, and ricotta salata, a classic Catanian dish.'
      },
      {
        id: 'sc3',
        name: 'Cannoli',
        description: 'Crispy pastry tubes filled with sweet ricotta cream and pistachios.'
      },
      {
        id: 'sc4',
        name: 'Granita',
        description: 'Semi-frozen dessert served with brioche, traditionally eaten for breakfast.'
      }
    ],
    events: [
      {
        id: 'se1',
        name: 'Taormina Film Fest',
        date: 'June',
        description: 'International film festival in the ancient Greek theater.'
      },
      {
        id: 'se2',
        name: 'Festa di Sant\'Agata',
        date: 'February',
        description: 'Religious festival in Catania honoring the city\'s patron saint.'
      },
      {
        id: 'se3',
        name: 'Infiorata',
        date: 'May',
        description: 'Flower festival in Noto where streets are decorated with floral designs.'
      }
    ],
    culture: 'Sicily reflects a rich cultural heritage from Greek, Roman, Arab, and Norman influences, visible in its architecture, cuisine, and traditions. The island maintains strong connections to family, tradition, and local festivals.',
    bestTimeToVisit: 'April to June or September to October for pleasant weather and fewer tourists. Spring brings wildflowers and mild temperatures, while fall offers harvest festivals and wine events.',
    tips: [
      'Try the famous Sicilian street food',
      'Visit Greek temples early in the morning',
      'Take guided tours of Mount Etna',
      'Experience local markets',
      'Learn basic Sicilian phrases',
      'Use public transportation between cities',
      'Book accommodations in historic centers',
      'Try local wines from volcanic soils',
      'Respect siesta hours'
    ]
  },
  {
    id: '6',
    name: 'Milan',
    description: 'Milan, Italy\'s dynamic financial and fashion capital, is a sophisticated metropolis where historical heritage meets modern innovation. Behind its business facade lies a city rich in art, architecture, and cultural attractions, from the magnificent Gothic cathedral to Leonardo da Vinci\'s Last Supper. As a global fashion and design hub, Milan sets worldwide trends while maintaining its traditional charm through historic cafes, art galleries, and world-class opera. The city\'s efficient blend of history and contemporary life makes it a unique destination in Italy.',
    image: 'https://images.unsplash.com/photo-1520440229-6469a149ac59?auto=format&fit=crop&w=1200&h=800',
    mapImage: 'https://images.unsplash.com/photo-1610016302534-6f67f1c968d8?auto=format&fit=crop&w=1200&h=800',
    rating: 4.6,
    safetyScore: 8,
    categories: ['historical', 'activities', 'culinary'],
    attractions: [
      {
        id: 'm1',
        name: 'Duomo di Milano',
        description: 'Gothic cathedral and symbol of Milan, featuring stunning architecture and city views from its accessible rooftop.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1572883454114-1cf0031ede2a?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'm2',
        name: 'The Last Supper',
        description: 'Leonardo da Vinci\'s masterpiece housed in the Church of Santa Maria delle Grazie.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1572883454114-1cf0031ede2a?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'm3',
        name: 'Galleria Vittorio Emanuele II',
        description: 'Historic shopping arcade with luxury boutiques and elegant cafes under a glass-vaulted ceiling.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1572883454114-1cf0031ede2a?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'm4',
        name: 'Sforza Castle',
        description: 'Medieval fortress housing several museums and art collections, including works by Michelangelo.',
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1572883454114-1cf0031ede2a?auto=format&fit=crop&w=1200&h=800'
      }
    ],
    cuisine: [
      {
        id: 'mc1',
        name: 'Risotto alla Milanese',
        description: 'Saffron-flavored risotto, a classic Milanese dish often served with osso buco.'
      },
      {
        id: 'mc2',
        name: 'Cotoletta alla Milanese',
        description: 'Breaded veal cutlet, Milan\'s signature dish that inspired the Wiener Schnitzel.'
      },
      {
        id: 'mc3',
        name: 'Panettone',
        description: 'Traditional sweet bread loaf originating from Milan, especially popular during Christmas.'
      },
      {
        id: 'mc4',
        name: 'Aperitivo',
        description: 'Pre-dinner drinks and snacks, a Milanese tradition that has spread throughout Italy.'
      }
    ],
    events: [
      {
        id: 'me1',
        name: 'Milan Fashion Week',
        date: 'February and September',
        description: 'One of the world\'s most important fashion events showcasing Italian and international designers.'
      },
      {
        id: 'me2',
        name: 'Salone del Mobile',
        date: 'April',
        description: 'International furniture and design fair attracting creative professionals worldwide.'
      },
      {
        id: 'me3',
        name: 'Piano City Milano',
        date: 'May',
        description: 'Weekend-long piano festival with concerts throughout the city.'
      }
    ],
    culture: 'Milan combines fashion, design, and business with rich artistic heritage, exemplified by Leonardo da Vinci\'s Last Supper. The city\'s culture emphasizes innovation, style, and efficiency while maintaining traditions like aperitivo and opera.',
    bestTimeToVisit: 'April to May or September to October for comfortable weather and fashion events. Winter can be cold and foggy, while summer is hot and humid.',
    tips: [
      'Book Last Supper tickets months in advance',
      'Visit the rooftop of the Duomo',
      'Experience aperitivo culture',
      'Shop during the sales seasons',
      'Use the efficient metro system',
      'Visit museums on free Sundays',
      'Explore design districts like Brera',
      'Try traditional Milanese breakfast',
      'Take day trips to Lake Como'
    ]
  },
  {
    id: '7',
    name: 'Cinque Terre',
    description: 'Cinque Terre, meaning "Five Lands," comprises five ancient fishing villages perched along Italy\'s rugged Ligurian coast. These colorful settlements - Monterosso al Mare, Vernazza, Corniglia, Manarola, and Riomaggiore - are connected by scenic hiking trails and a railway line carved through the cliffs. Each village has its own character, from the beach resort atmosphere of Monterosso to the romantic harbor of Vernazza. The entire area is a UNESCO Worl d Heritage site, celebrated for its dramatic landscapes, centuries-old agricultural traditions, and the harmonious relationship between human settlement and nature.',
    image: 'https://images.unsplash.com/photo-1498307833015-e7b400441eb8?auto=format&fit=crop&w=1200&h=800',
    mapImage: 'https://images.unsplash.com/photo-1526913597804-20372d0d5351?auto=format&fit=crop&w=1200&h=800',
    rating: 4.8,
    safetyScore: 9,
    categories: ['outdoor', 'culinary', 'activities'],
    attractions: [
      {
        id: 'ct1',
        name: 'Vernazza',
        description: 'Perhaps the most picturesque of the five villages, with a natural harbor, castle ruins, and the Church of Santa Margherita d\'Antiochia overlooking the sea.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1591818320186-6f5d6caad6b3?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'ct2',
        name: 'Sentiero Azzurro',
        description: 'The famous "Blue Trail" connecting all five villages, offering stunning coastal views and varying degrees of hiking difficulty.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1591818320186-6f5d6caad6b3?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'ct3',
        name: 'Manarola Vineyard Terraces',
        description: 'Ancient terraced vineyards climbing the steep hillsides, producing local wines and offering spectacular sunset views.',
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1591818320186-6f5d6caad6b3?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'ct4',
        name: 'Monterosso Beach',
        description: 'The largest beach in Cinque Terre, featuring crystal clear waters and traditional striped umbrellas.',
        rating: 4.6,
        image: 'https://images.unsplash.com/photo-1591818320186-6f5d6caad6b3?auto=format&fit=crop&w=1200&h=800'
      }
    ],
    cuisine: [
      {
        id: 'ctc1',
        name: 'Pesto alla Genovese',
        description: 'Traditional basil pesto, originating from the nearby Liguria region, served with local pasta varieties.'
      },
      {
        id: 'ctc2',
        name: 'Anchovies of Monterosso',
        description: 'Local specialty prepared according to ancient traditions, served fresh or salted.'
      },
      {
        id: 'ctc3',
        name: 'Farinata',
        description: 'Traditional chickpea flatbread, a popular street food in the region.'
      },
      {
        id: 'ctc4',
        name: 'Sciacchetrà',
        description: 'Sweet dessert wine made from locally grown grapes on the terraced vineyards.'
      }
    ],
    events: [
      {
        id: 'cte1',
        name: 'Lemon Festival',
        date: 'May',
        description: 'Celebration of the local citrus harvest in Monterosso, featuring food, music, and cultural events.'
      },
      {
        id: 'cte2',
        name: 'Feast of San Giovanni Battista',
        date: 'June 24',
        description: 'Religious celebration in Monterosso with processions and traditional events.'
      },
      {
        id: 'cte3',
        name: 'Vendemmia',
        date: 'September',
        description: 'Traditional grape harvest in the terraced vineyards, sometimes open to public participation.'
      }
    ],
    culture: 'These five villages have preserved their traditional way of life, with wine terraces and fishing still being important parts of local culture. The communities maintain strong ties to their maritime heritage while adapting to modern tourism.',
    bestTimeToVisit: 'Mid-March to mid-October for hiking and swimming, though September is ideal. Spring offers wildflowers and mild temperatures, while fall brings wine harvest celebrations.',
    tips: [
      'Purchase the Cinque Terre Card for hiking and trains',
      'Start hikes early in the morning',
      'Make dinner reservations in advance',
      'Check trail conditions before hiking',
      'Use the train to travel between villages',
      'Bring water shoes for rocky beaches',
      'Try the local white wines',
      'Visit during shoulder season for fewer crowds',
      'Book accommodations well in advance'
    ]
  },
  {
    id: '8',
    name: 'Dolomites',
    description: 'The Dolomites, a UNESCO World Heritage site in northern Italy, are a mountain range of extraordinary beauty featuring dramatic limestone peaks, verdant valleys, and charming Alpine villages. This region offers year-round outdoor activities, from world-class skiing in winter to hiking and rock climbing in summer. The area\'s unique culture blends Italian, Austrian, and Ladin influences, creating a distinctive atmosphere reflected in its architecture, cuisine, and traditions. The mountains are known for their distinctive color changes throughout the day, most spectacularly at sunset when they take on a pink and purple hue known as "enrosadira."',
    image: 'https://images.unsplash.com/photo-1618173745201-8e3bf8978acc?auto=format&fit=crop&w=1200&h=800',
    mapImage: 'https://images.unsplash.com/photo-1601055283742-8b27e81b5553?auto=format&fit=crop&w=1200&h=800',
    rating: 4.9,
    safetyScore: 8,
    categories: ['outdoor', 'activities', 'culinary'],
    attractions: [
      {
        id: 'd1',
        name: 'Tre Cime di Lavaredo',
        description: 'Three distinctive battlement-like peaks, symbol of the Dolomites, offering iconic hiking trails and photography opportunities.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1571676906638-adf27a4578fb?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'd2',
        name: 'Lake Braies',
        description: 'Crystal-clear Alpine lake surrounded by towering peaks, popular for boating and photography.',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1571676906638-adf27a4578fb?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'd3',
        name: 'Cortina d\'Ampezzo',
        description: 'Prestigious mountain resort town offering luxury shopping, dining, and access to premier ski slopes.',
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1571676906638-adf27a4578fb?auto=format&fit=crop&w=1200&h=800'
      },
      {
        id: 'd4',
        name: 'Alta Via 1',
        description: 'Long-distance hiking trail through the Dolomites, offering stunning mountain scenery and overnight stays in rifugios.',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1571676906638-adf27a4578fb?auto=format&fit=crop&w=1200&h=800'
      }
    ],
    cuisine: [
      {
        id: 'dc1',
        name: 'Canederli',
        description: 'Bread dumplings served in broth, a hearty mountain dish reflecting the region\'s Austrian influence.'
      },
      {
        id: 'dc2',
        name: 'Speck Alto Adige',
        description: 'Local cured and smoked ham, a staple of the region\'s cuisine.'
      },
      {
        id: 'dc3',
        name: 'Kaiserschmarrn',
        description: 'Shredded pancake dessert served with fruit preserves, popular in mountain refuges.'
      },
      {
        id: 'dc4',
        name: 'Polenta',
        description: 'Traditional cornmeal dish served with local cheeses, mushrooms, or game meat.'
      }
    ],
    events: [
      {
        id: 'de1',
        name: 'Sounds of the Dolomites',
        date: 'July to August',
        description: 'Open-air music festival featuring concerts in natural amphitheaters throughout the mountains.'
      },
      {
        id: 'de2',
        name: 'Cortina Winter Polo',
        date: 'February',
        description: 'Prestigious polo tournament played on snow in Cortina d\'Ampezzo.'
      },
      {
        id: 'de3',
        name: 'Südtirol Gardenissima',
        date: 'April',
        description: 'Popular skiing event in Val Gardena with both professional and amateur races.'
      }
    ],
    culture: 'The region blends Italian, Austrian, and Ladin cultures, reflected in its cuisine, architecture, and traditions. The Ladin language and culture are still preserved in many valleys, adding to the area\'s unique cultural heritage.',
    bestTimeToVisit: 'June to September for hiking and climbing, December to March for skiing and winter sports. Fall offers beautiful foliage and fewer tourists.',
    tips: [
      'Check weather forecasts before mountain activities',
      'Book rifugios (mountain huts) in advance',
      'Bring proper hiking or skiing equipment',
      'Try the unique Alpine-Mediterranean cuisine',
      'Learn basic German and Italian phrases',
      'Use cable cars for easier mountain access',
      'Purchase multi-day ski passes for better value',
      'Respect mountain safety guidelines',
      'Consider hiring a mountain guide for difficult trails'
    ]
  }
];