import React, { useState } from 'react';
import { ArrowLeft, Star, Shield, MapPin, Utensils, Calendar, Info } from 'lucide-react';
import { Region } from '../types';
import RegionMap from './RegionMap';

interface RegionDetailsProps {
  region: Region;
  onBack: () => void;
}

const RegionDetails: React.FC<RegionDetailsProps> = ({ region, onBack }) => {
  const [activeTab, setActiveTab] = useState('attractions');

  const tabs = [
    { id: 'attractions', label: 'Attractions', icon: MapPin },
    { id: 'cuisine', label: 'Local Cuisine', icon: Utensils },
    { id: 'events', label: 'Events', icon: Calendar },
    { id: 'info', label: 'Information', icon: Info },
  ];

  return (
    <div>
      <button
        onClick={onBack}
        className="flex items-center text-emerald-600 hover:text-emerald-700 mb-6"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        Back to Regions
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <img
              src={region.image}
              alt={region.name}
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-3xl font-bold">{region.name}</h1>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <Star className="w-5 h-5 text-yellow-500 mr-1" />
                    <span className="font-semibold">{region.rating}</span>
                  </div>
                  <div className="flex items-center">
                    <Shield className="w-5 h-5 text-emerald-500 mr-1" />
                    <span className="font-semibold">Safety: {region.safetyScore}/10</span>
                  </div>
                </div>
              </div>

              <div className="border-b border-gray-200">
                <nav className="flex space-x-8">
                  {tabs.map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                        activeTab === tab.id
                          ? 'border-emerald-500 text-emerald-600'
                          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      <tab.icon className="w-5 h-5" />
                      <span>{tab.label}</span>
                    </button>
                  ))}
                </nav>
              </div>

              <div className="mt-6">
                {activeTab === 'attractions' && (
                  <div className="space-y-6">
                    {region.attractions.map(attraction => (
                      <div key={attraction.id} className="border-b border-gray-200 pb-6 last:border-0">
                        <h3 className="text-xl font-semibold mb-2">{attraction.name}</h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                          <div className="flex items-center">
                            <Star className="w-4 h-4 text-yellow-500 mr-1" />
                            <span>{attraction.rating}</span>
                          </div>
                        </div>
                        <p className="text-gray-600">{attraction.description}</p>
                      </div>
                    ))}
                  </div>
                )}

                {activeTab === 'cuisine' && (
                  <div className="space-y-6">
                    {region.cuisine.map(dish => (
                      <div key={dish.id} className="border-b border-gray-200 pb-6 last:border-0">
                        <h3 className="text-xl font-semibold mb-2">{dish.name}</h3>
                        <p className="text-gray-600">{dish.description}</p>
                      </div>
                    ))}
                  </div>
                )}

                {activeTab === 'events' && (
                  <div className="space-y-6">
                    {region.events.map(event => (
                      <div key={event.id} className="border-b border-gray-200 pb-6 last:border-0">
                        <h3 className="text-xl font-semibold mb-2">{event.name}</h3>
                        <p className="text-sm text-gray-500 mb-2">{event.date}</p>
                        <p className="text-gray-600">{event.description}</p>
                      </div>
                    ))}
                  </div>
                )}

                {activeTab === 'info' && (
                  <div className="prose max-w-none">
                    <p>{region.description}</p>
                    <h3>Local Culture</h3>
                    <p>{region.culture}</p>
                    <h3>Best Time to Visit</h3>
                    <p>{region.bestTimeToVisit}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <RegionMap region={region} />
          <div className="bg-white rounded-xl shadow-md p-4">
            <h3 className="text-lg font-semibold mb-4">Quick Tips</h3>
            <ul className="space-y-3">
              {region.tips.map((tip, index) => (
                <li key={index} className="flex items-start">
                  <Info className="w-5 h-5 text-emerald-500 mr-2 flex-shrink-0 mt-1" />
                  <span className="text-gray-600">{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default RegionDetails;