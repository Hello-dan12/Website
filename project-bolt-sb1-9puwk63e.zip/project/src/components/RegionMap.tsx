import React from 'react';
import { Region } from '../types';

interface RegionMapProps {
  region: Region;
}

const RegionMap: React.FC<RegionMapProps> = ({ region }) => {
  return (
    <div className="bg-white rounded-xl shadow-md p-4">
      <h3 className="text-lg font-semibold mb-4">Map of {region.name}</h3>
      <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
        <img
          src={region.mapImage}
          alt={`Map of ${region.name}`}
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  );
}

export default RegionMap;