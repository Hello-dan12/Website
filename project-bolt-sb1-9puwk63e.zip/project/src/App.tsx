import React, { useState } from 'react';
import { Map, Search, Star, Shield, Info, ArrowLeft, Coffee, Mountain, Building, Bike } from 'lucide-react';
import RegionMap from './components/RegionMap';
import RegionDetails from './components/RegionDetails';
import { regions } from './data/regions';
import { Region } from './types';

function App() {
  const [selectedRegion, setSelectedRegion] = useState<Region | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>('all');

  const filters = [
    { id: 'all', label: 'All', icon: Map },
    { id: 'historical', label: 'Historical', icon: Building },
    { id: 'outdoor', label: 'Outdoor', icon: Mountain },
    { id: 'culinary', label: 'Culinary', icon: Coffee },
    { id: 'activities', label: 'Activities', icon: Bike },
  ];

  const filteredRegions = regions.filter(region => 
    region.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (activeFilter === 'all' || region.categories.includes(activeFilter))
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-emerald-700 text-white py-6 px-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Map className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Italia Explorer</h1>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search regions..."
              className="pl-10 pr-4 py-2 rounded-full bg-emerald-800 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {selectedRegion ? (
          <RegionDetails
            region={selectedRegion}
            onBack={() => setSelectedRegion(null)}
          />
        ) : (
          <>
            {/* Filters */}
            <div className="flex items-center space-x-4 mb-8 overflow-x-auto pb-4">
              {filters.map(filter => (
                <button
                  key={filter.id}
                  onClick={() => setActiveFilter(filter.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-colors ${
                    activeFilter === filter.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-emerald-50'
                  }`}
                >
                  <filter.icon className="w-4 h-4" />
                  <span>{filter.label}</span>
                </button>
              ))}
            </div>

            {/* Regions Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredRegions.map(region => (
                <div
                  key={region.id}
                  className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setSelectedRegion(region)}
                >
                  <img
                    src={region.image}
                    alt={region.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <h2 className="text-xl font-semibold mb-2">{region.name}</h2>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-500 mr-1" />
                        <span>{region.rating}</span>
                      </div>
                      <div className="flex items-center">
                        <Shield className="w-4 h-4 text-emerald-500 mr-1" />
                        <span>Safety: {region.safetyScore}/10</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  );
}

export default App;